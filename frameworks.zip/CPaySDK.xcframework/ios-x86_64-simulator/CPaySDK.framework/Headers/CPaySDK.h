//
//  CPaySDK.h
//  CPaySDK
//
//  Created by long.zhao on 2/7/22.
//

#import <Foundation/Foundation.h>

//! Project version number for CPaySDK.
FOUNDATION_EXPORT double CPaySDKVersionNumber;

//! Project version string for CPaySDK.
FOUNDATION_EXPORT const unsigned char CPaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CPaySDK/PublicHeader.h>

